package com.ecoplate.canteen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
